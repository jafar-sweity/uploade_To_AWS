export namespace Book {
  export interface book {
    id: number;
    title: string;
    author: string;
    publicationYear: number;
  }
}

export default Book;
